<?php
$host="localhost";
$user="root";
$password="";
$dbname="ecommerce";
$connect=mysqli_connect($host,$user,$password,$dbname);

// if($connect -> mysqli_error){
// 	echo "NOTCONNECTED!!!";
// }
// else{
// 	echo "CONNECTED!!!";
// }
?>