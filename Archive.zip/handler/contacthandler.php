<?php 
	include("../partials/connect.php");
	$email = $_POST['email'];
	$msg = $_POST['msg'];

	$set = "INSERT INTO contact (Email,Msg) VALUES ('$email','$msg')";
	$set = mysqli_query($connect, $set);
?>