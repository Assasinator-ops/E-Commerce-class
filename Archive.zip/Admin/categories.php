</<?php 
include("");
 ?>
<!DOCTYPE html>
<html>
<?php
include("adminpartials/head.php");
?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

 <?php
    include("adminpartials/header.php");
  ?>
  <!-- Left side column. contains the logo and sidebar -->
 
<?php
include("adminpartials/aside.php");
?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="row">
        <div class="col-sm-3"></div>
        <div class="col-sm-6">
       <form role="form">
              <div class="box-body">
                <div class="form-group">
                  <label for="exampleInputEmail1">Category Name</label>
                  <input type="text" class="form-control" id="category" placeholder="Enter Category" name="Name">
                </div>
                
              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
            </div>
          <div class="col-sm-3"></div>
          </div>
    </section>

    <!-- Main content -->
 
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php
include("adminpartials/footer.php");
?>

</body>
</html>
